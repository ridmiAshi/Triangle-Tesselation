#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main(){
while(1){
	int r,g,b,p1x,p2x,p3x,p1y,p2y,p3y;
	//scanf("%d",&r);	
	printf("R--->\n");
	scanf("%d",&r);	
	printf("G--->\n");
	scanf("%d",&g);
	printf("B--->\n");
	scanf("%d",&b);
	printf("\n*********\n");
	printf("p1(x,y)--->\n");
	scanf("%d,%d",&p1x,&p1y);
	printf("2(x,y)--->\n");
	scanf("%d,%d",&p2x,&p2y);
	printf("p3(x,y)--->\n");
	scanf("%d,%d",&p3x,&p3y);
//	printf("%f",(float)r/255.0);
/*p1x-=175;
p2x-=175;
p3x-=175;
p1y-=175;
p2y-=175;
p3y-=175;*/

	printf("\n*********\n");
	printf("glBegin (GL_TRIANGLES);\nglColor3f (%.2f, %.2f,%.2f);   glVertex2f (%.2f, %.2f);\n",(float)r/255,(float)g/255,(float)b/255,(float)p1x/190,(float)p1y/190);
	printf("glColor3f (%.2f, %.2f,%.2f);   glVertex2f (%.2f, %.2f);\n",(float)r/255,(float)g/255,(float)b/255,(float)p2x/190,(float)p2y/190);   
	printf("glColor3f (%.2f, %.2f,%.2f);   glVertex2f (%.2f, %.2f);\nglEnd ();",(float)r/255,(float)g/255,(float)b/255,(float)p3x/190,(float)p3y/190);
	printf("\n*********\n\n");
	getch();
	
}}
